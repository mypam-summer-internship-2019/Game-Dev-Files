
If you have any issues, ideas or suggestion on improvements please email Mitchell at "mitchellmypam@hotmail.com" and I will respond as quickly as possible.
Examples of how the files have been implemented into other games can be found at these links:
- https://github.com/mypam-summer-internship-2019/Monkey-Bridge-Game (Monkey Bridge Game) 
- https://github.com/mypam-summer-internship-2019/Maze-Game (Maze Game)

latest Version of the MyPAM Game Dev Package: https://github.com/mypam-summer-internship-2019/Game-Dev-Files

==================================================================================================================


Install Instructions
- Copy the 'JSonDotNet' folder into the assets folder of the project - this can go into sub folders such as an "Imports" folder for any imported packages.

- Place the UDP_Handling.cs script in your scripts and attach it to a game object that will never be destroyed as this will 
  stop the MyPAM being able to communicate with the game.
- This gameobject can be copied into every scene, but it will work fine so long as it is in the very first scene that loads when the game is run.
  Adding it to every scene allows it to work if you are testing scenes without loading the first scene.

- Unless making a fundamental change, do not edit the 'UDP_Handler' script. Create new scripts and access variables 
  e.g. set a variable to the value of X2pos by using 'double xInput = UDP_Handler.X2pos'

- Make sure your game has its Api Compatibility Level to: ".NET 4.X". 
- This setting is found under File > Build Settings > Player Settings > Settings for PC... > Other Settings > Configuration > Api Compatibility Level > Select .NET 4.x


===================================================================================================================
Running Builds and Testing Games

- When testing games in the editor or running builds always use the vircutal controller buy running the "MyPAM Virtual Controller.exe" in the "MyPAM Virtual Controller_Data" folder.
- Ensure Unity Editor is closed when trying to run a build as it may cause issuses with the UDP communication.
- Ensure the latest version of 'UDP_Handler' and 'Virtual Controller' is in use.


===================================================================================================================
UDP_Handling Class - Important Parts
Data To Game
-Example Code
"savedXPos = (float)(UDP_Handling.X2pos);" : Returns the X position of the MyPAM handle and converts the data to a float and sets it equal to the "savedXPos" variable.
"savedYPos = (float)(UDP_Handling.Y2pos);" : Returns the Y position of the MyPAM handle and converts the data to a float and sets it equal to the "savedXPos" variable.

Data Names
X2pos : The X position of the MyPAM handle (Important) (Double)
Y2pos : The Y position of the MyPAM handle (Important) (Double)
Z2pos : The Z position of the MyPAM handle (Important) (Double)
ErrorOccurred: States whether there is a problem with the arm (Bool) (Important) (True = Error has occurred)

Data From Game (To MyPAM)
-Example Code
"UDP_Handling.Xtarget = target.x;" : Sets the X position of the target the MyPAM will go to as the vale stroed in variable "target.x"
"UDP_Handling.Ytarget = target.y;" : Sets the Y position of the target the MyPAM will go to as the vale stroed in variable "target.y"

Data Names
Xtarget : Sets the X position of the target the MyPAM handle will go toward (Default = 0) (Important) (Double)
Ytarget : Sets the Y position of the target the MyPAM handle will go toward (Default = 0) (Important) (Double)
Ztarget : Sets the Z position of the target the MyPAM handle will go toward (Default = 0) (Important) (Double)
Traj_Flag : Sets whether the MyPAM or the games will generate the trajectory it will travel in (Default = true) (False = games generate own trajectory) (Important) (bool)
Assistance : Sets whether assistance is provided to the user or not (Default = True) (True = Assistance is on) (Important) (bool)
Shutdown : Tells the MyPAM the game is being shutdown (Default = False) (bool)
AssistanceLevel : Sets the level of assistance for the user in the range 0 - 100 (Default = 50) (0 = MIN, 100 = MAX assistance ) (Important) (Double)


====================================================================================================================
UDP_Handling Class - Full Over view

Data To Game
-Example Code
"savedXPos = (float)(UDP_Handling.X2pos);" : Returns the X position of the MyPAM handle and converts the data to a float and sets it equal to the "savedXPos" variable.
"savedYPos = (float)(UDP_Handling.Y2pos);" : Returns the Y position of the MyPAM handle and converts the data to a float and sets it equal to the "savedXPos" variable.

Data Names
X2pos : The X position of the MyPAM handle (Important) (Double)
Y2pos : The Y position of the MyPAM handle (Important) (Double)
Z2pos : The Z position of the MyPAM handle (Important) (Double)
X1pos : The X position of the MyPAM elbow (Double)
Y1pos : The Y position of the MyPAM elbow  (Double)
Z1pos : The Z position of the MyPAM elbow (Double)
X0pos : The X position of the MyPAM base (Should always be 0) (Double)
Y0pos : The Y position of the MyPAM base (Should always be 0) (Double)
Z0pos : The Z position of the MyPAM base (Should always be 0) (Double)
Fx : The force applied on the MyPAM in the X axis (Not yet implemented) (Double)
Fy : The force applied on the MyPAM in the Y axis (Not yet implemented) (Double)
Fz : The force applied on the MyPAM in the Z axis (Not yet implemented) (Double)
Encoder1 : Raw data from encoder 1 (int)
Encoder2 : Raw data from encoder 2 (int)
Pot1 : Raw data from pot 1 (Double)
Pot2 : Raw data from pot 2 (Double)
Theta0: Angle of the upper arm relative to the base (Double)
Theta1: Angle of the lower arm relative to the base (Double)
ErrorOccurred: States whether there is a problem with the arm (Bool) (Important) (True = Error has occurred)


Data From Game (To MyPAM)
-Example Code
"UDP_Handling.Xtarget = target.x;" : Sets the X position of the target the MyPAM will go to as the vale strode in variable "target.x"
"UDP_Handling.Ytarget = target.y;" : Sets the Y position of the target the MyPAM will go to as the vale strode in variable "target.y"

Data Names
Xtarget : Sets the X position of the target the MyPAM handle will go toward (Default = 0) (Important) (Double)
Ytarget : Sets the Y position of the target the MyPAM handle will go toward (Default = 0) (Important) (Double)
Ztarget : Sets the Z position of the target the MyPAM handle will go toward (Default = 0) (Important) (Double)
X_Attractor1 : Sets X position of the first attractor (Default = NULL) (Double)
Y_Attractor1 : Sets Y position of the first attractor (Default = NULL) (Double)
Z_Attractor1 : Sets Z position of the first attractor (Default = NULL) (Double)
X_Attractor2 : Sets X position of the second attractor (Default = NULL) (Double)
Y_Attractor2 : Sets Y position of the second attractor (Default = NULL) (Double)
Z_Attractor2 : Sets Z position of the second attractor (Default = NULL) (Double)
DeadZone : Set diameter of dead zone for the MyPAM target (Default = 0) (Double)
Traj_Flag : Sets whether the MyPAM or the games will generate the trajectory it will travel in (Default = true) (False = games generate own trajectory) (Important) (bool)
Assistance : Sets whether assistance is provided to the user or not (Default = True) (True = Assistance is on) (Important) (bool)
Shutdown : Tells the MyPAM the game is being shutdown (Default = False) (bool)
AssistanceLevel : Sets the level of assistance for the user in the range 0 - 100 (Default = 50) (0 = MIN, 100 = MAX assistance ) (Important) (Double)







